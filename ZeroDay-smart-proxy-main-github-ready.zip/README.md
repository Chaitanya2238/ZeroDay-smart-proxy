# ZeroDay Smart Proxy

<p align="center">
  FastAPI reverse proxy with a live security dashboard and a Phase 2 analyzer for suspicious traffic detection.
</p>

<p align="center">
  <img src="https://img.shields.io/badge/python-3.10%2B-3776AB?style=for-the-badge&logo=python&logoColor=white" alt="Python 3.10+">
  <img src="https://img.shields.io/badge/fastapi-dashboard-009688?style=for-the-badge&logo=fastapi&logoColor=white" alt="FastAPI Dashboard">
  <img src="https://img.shields.io/badge/license-MIT-111111?style=for-the-badge" alt="MIT License">
  <img src="https://img.shields.io/badge/status-github%20ready-56e39f?style=for-the-badge" alt="GitHub Ready">
</p>

## Overview

ZeroDay Smart Proxy is a local security-focused reverse proxy that:

- forwards requests to a target backend
- logs all incoming traffic to `proxy.log`
- analyzes suspicious requests through a two-tier pipeline
- exposes a polished dashboard at `/dashboard`
- supports local testing through a mock backend and attack simulation scripts

## Features

- FastAPI reverse proxy with support for standard HTTP methods
- Request logging with body preview, timing, IP, and response metadata
- Phase 2 rule-based analyzer for fast suspicious-traffic detection
- AI-assisted escalation path for ambiguous threat cases
- Frontend dashboard for summary metrics, alerts, traffic, and hot paths
- Mock backend for local development and demos
- GitHub Actions workflow for install, compile, and test validation

## Dashboard

The dashboard is served directly by the FastAPI app:

```text
http://localhost:8000/dashboard
```

It includes:

- operational summary cards
- service readiness status
- top suspicious IPs
- request status and threat charts
- recent alerts feed
- recent proxy request timeline

## Project Structure

```text
ZeroDay-smart-proxy-main/
|-- .github/
|   `-- workflows/
|       `-- ci.yml
|-- frontend/
|   |-- app.js
|   |-- index.html
|   `-- styles.css
|-- phase2/
|   |-- __init__.py
|   |-- ai_engine.py
|   |-- alerts.json
|   |-- analyzer.py
|   |-- analyzer_state.json
|   |-- README.md
|   |-- requirements.txt
|   |-- rules.py
|   `-- statistics.json
|-- tests/
|   |-- __init__.py
|   |-- test_analyzer_full.py
|   |-- test_api_key.py
|   |-- test_gemini_integration.py
|   |-- test_reallife_zeroday.py
|   |-- test_tier1_rules.py
|   `-- test_tier2_ai_engine.py
|-- .env.example
|-- .gitignore
|-- LICENSE
|-- README.md
|-- config.py
|-- load_env.ps1
|-- main.py
|-- MANUAL_TESTING_GUIDE.md
|-- mock_backend.py
`-- requirements.txt
```

## Requirements

- Python 3.10 or newer
- `pip`
- PowerShell on Windows for the exact commands below

## Installation

```powershell
git clone <your-repo-url>
cd ZeroDay-smart-proxy-main
pip install -r requirements.txt
```

## Configuration

Optional environment variables:

```powershell
$env:TARGET_BACKEND="http://localhost:3000"
$env:PROXY_PORT="8000"
```

If you want AI-based Phase 2 analysis, configure your API key in `.env` or through environment variables as expected by the analyzer setup in this repository.

## Quick Start

### 1. Start the mock backend

```powershell
python .\mock_backend.py
```

### 2. Start the reverse proxy and dashboard

```powershell
uvicorn main:app --host localhost --port 8000 --reload
```

### 3. Open the dashboard

```text
http://localhost:8000/dashboard
```

## Run the Analyzer

Open a separate terminal and run:

```powershell
python -m phase2.analyzer proxy.log
```

## Generate Test Traffic

To simulate attack requests:

```powershell
python .\tests\test_reallife_zeroday.py
```

This will:

- send attack traffic through the proxy
- populate `proxy.log`
- feed the analyzer
- generate visible dashboard activity

## Main Endpoints

- `/dashboard` for the frontend dashboard
- `/dashboard/api/state` for dashboard JSON state
- `/health` for the health check

## Development Checks

Run a quick compile validation:

```powershell
python -m py_compile main.py mock_backend.py phase2\analyzer.py
```

Run tests:

```powershell
pytest
```

## Publish To GitHub

```powershell
git init
git add .
git commit -m "Add smart proxy dashboard and GitHub-ready project setup"
git branch -M main
git remote add origin https://github.com/<your-username>/<your-repo-name>.git
git push -u origin main
```

## GitHub-Ready Inclusions

- root `requirements.txt`
- polished `README.md`
- `LICENSE`
- GitHub Actions workflow at `.github/workflows/ci.yml`
- cleaned `.gitignore`

## License

This project is licensed under the MIT License. See [LICENSE](./LICENSE).
