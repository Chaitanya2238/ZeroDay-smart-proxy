from collections import Counter
from datetime import datetime
import json
import logging
from pathlib import Path
from typing import Any

import httpx
from fastapi import FastAPI, Request, Response
from fastapi.responses import FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles

from config import TARGET_BACKEND


BASE_DIR = Path(__file__).resolve().parent
PHASE2_DIR = BASE_DIR / "phase2"
FRONTEND_DIR = BASE_DIR / "frontend"
PROXY_LOG_PATH = BASE_DIR / "proxy.log"
ROOT_ALERTS_PATH = BASE_DIR / "alerts.json"
ROOT_STATS_PATH = BASE_DIR / "statistics.json"
PHASE2_ALERTS_PATH = PHASE2_DIR / "alerts.json"
PHASE2_STATS_PATH = PHASE2_DIR / "statistics.json"
PHASE2_STATE_PATH = PHASE2_DIR / "analyzer_state.json"


logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    handlers=[logging.StreamHandler()],
)
logger = logging.getLogger(__name__)

app = FastAPI(title="Smart Proxy")
client = httpx.AsyncClient(timeout=30.0)

if FRONTEND_DIR.exists():
    app.mount(
        "/dashboard/static",
        StaticFiles(directory=str(FRONTEND_DIR)),
        name="dashboard-static",
    )


def _safe_read_json(path: Path, fallback: Any) -> Any:
    if not path.exists():
        return fallback

    try:
        with path.open("r", encoding="utf-8") as file:
            return json.load(file)
    except Exception as exc:
        logger.warning("Could not read JSON from %s: %s", path, exc)
        return fallback


def _read_recent_proxy_entries(limit: int = 60) -> list[dict[str, Any]]:
    if not PROXY_LOG_PATH.exists():
        return []

    try:
        with PROXY_LOG_PATH.open("r", encoding="utf-8", errors="ignore") as file:
            lines = [line.strip() for line in file if line.strip()]
    except Exception as exc:
        logger.warning("Could not read proxy log: %s", exc)
        return []

    recent_entries: list[dict[str, Any]] = []
    for line in lines[-limit:]:
        try:
            recent_entries.append(json.loads(line))
        except json.JSONDecodeError:
            logger.warning("Skipping malformed proxy log line")

    recent_entries.reverse()
    return recent_entries


def _format_timestamp(value: str | None) -> str | None:
    if not value:
        return None

    try:
        return datetime.fromisoformat(value).strftime("%d %b %Y, %I:%M:%S %p")
    except ValueError:
        return value


def _severity_label(severity: int) -> str:
    if severity >= 9:
        return "critical"
    if severity >= 7:
        return "high"
    if severity >= 4:
        return "medium"
    return "low"


def _build_dashboard_state() -> dict[str, Any]:
    phase2_alerts_data = _safe_read_json(PHASE2_ALERTS_PATH, {"alerts": []})
    root_alerts_data = _safe_read_json(ROOT_ALERTS_PATH, {"alerts": []})
    phase2_stats = _safe_read_json(
        PHASE2_STATS_PATH,
        {
            "total_requests_processed": 0,
            "requests_by_status": {},
            "threats_by_type": {},
            "top_attacking_ips": {},
        },
    )
    root_stats = _safe_read_json(ROOT_STATS_PATH, {"total_requests_processed": 0})
    analyzer_state = _safe_read_json(PHASE2_STATE_PATH, {"last_position": 0})
    proxy_entries = _read_recent_proxy_entries()

    phase2_alerts = phase2_alerts_data.get("alerts", [])
    root_alerts = root_alerts_data.get("alerts", [])
    all_alerts = sorted(
        phase2_alerts + root_alerts,
        key=lambda alert: alert.get("timestamp", ""),
        reverse=True,
    )

    requests_by_status = phase2_stats.get("requests_by_status", {})
    threats_by_type = phase2_stats.get("threats_by_type", {})
    top_attacking_ips = phase2_stats.get("top_attacking_ips", {})
    recent_status_counts = Counter(
        str(entry.get("response_status", "unknown")) for entry in proxy_entries
    )
    recent_paths = Counter(entry.get("path", "/") or "/" for entry in proxy_entries)

    threat_categories = Counter(alert.get("threat_type", "UNKNOWN") for alert in all_alerts)
    high_severity_alerts = [
        alert for alert in all_alerts if int(alert.get("severity", 0) or 0) >= 7
    ]
    latest_alert = all_alerts[0] if all_alerts else None

    summary = {
        "total_requests_processed": phase2_stats.get(
            "total_requests_processed",
            root_stats.get("total_requests_processed", 0),
        ),
        "requests_flagged": requests_by_status.get("flagged_tier1", 0),
        "threats_detected": len(all_alerts),
        "high_severity_alerts": len(high_severity_alerts),
        "ai_analyses": requests_by_status.get("analyzed_by_ai", 0),
        "latest_alert_time": _format_timestamp(latest_alert.get("timestamp")) if latest_alert else None,
    }

    services = [
        {
            "name": "Reverse Proxy",
            "status": "online" if BASE_DIR.exists() else "unknown",
            "detail": f"Forwarding traffic to {TARGET_BACKEND}",
        },
        {
            "name": "Analyzer Files",
            "status": "online" if PHASE2_DIR.exists() else "offline",
            "detail": "Phase 2 rule engine and AI monitor available in project",
        },
        {
            "name": "Traffic Log",
            "status": "online" if PROXY_LOG_PATH.exists() else "waiting",
            "detail": "Waiting for proxy.log to be created by live traffic" if not PROXY_LOG_PATH.exists() else "Recent traffic available for analysis",
        },
        {
            "name": "Alerts Feed",
            "status": "online" if all_alerts else "quiet",
            "detail": f"{len(all_alerts)} total alerts loaded from available JSON stores",
        },
    ]

    alerts = []
    for alert in all_alerts[:12]:
        severity = int(alert.get("severity", 0) or 0)
        original = alert.get("original_request", {})
        alerts.append(
            {
                "alert_id": alert.get("alert_id"),
                "timestamp": _format_timestamp(alert.get("timestamp")),
                "severity": severity,
                "severity_label": _severity_label(severity),
                "threat_type": alert.get("threat_type", "UNKNOWN"),
                "confidence": round(float(alert.get("confidence", 0) or 0) * 100, 1),
                "recommended_action": alert.get("recommended_action", "investigate"),
                "path": original.get("path", "-"),
                "method": original.get("method", "-"),
                "client_ip": original.get("client_ip", "-"),
                "status_code": original.get("response_status", "-"),
                "body_preview": original.get("body_preview", ""),
                "triggered_rules": alert.get("tier1_analysis", {}).get("triggered_rules", []),
            }
        )

    traffic = []
    for entry in proxy_entries[:18]:
        traffic.append(
            {
                "timestamp": _format_timestamp(entry.get("timestamp")),
                "method": entry.get("method", "-"),
                "path": entry.get("path", "-"),
                "query": entry.get("query", ""),
                "client_ip": entry.get("client_ip", "-"),
                "status_code": entry.get("response_status", "-"),
                "response_time_ms": round(float(entry.get("response_time_ms", 0) or 0), 2),
                "response_size": entry.get("response_size", 0),
                "user_agent": entry.get("user_agent", "-"),
            }
        )

    top_ips = [
        {
            "ip": ip,
            "count": details.get("count", 0),
            "threats": Counter(details.get("threats", [])).most_common(3),
        }
        for ip, details in sorted(
            top_attacking_ips.items(),
            key=lambda item: item[1].get("count", 0),
            reverse=True,
        )[:6]
    ]

    return {
        "summary": summary,
        "services": services,
        "charts": {
            "request_statuses": [
                {"label": "Passed Tier 1", "value": requests_by_status.get("passed_tier1", 0)},
                {"label": "Flagged Tier 1", "value": requests_by_status.get("flagged_tier1", 0)},
                {"label": "Analyzed by AI", "value": requests_by_status.get("analyzed_by_ai", 0)},
                {"label": "Threat Detected", "value": requests_by_status.get("threat_detected", 0)},
            ],
            "threat_types": [
                {"label": label, "value": value}
                for label, value in (threats_by_type or threat_categories).items()
            ],
            "recent_status_codes": [
                {"label": label, "value": value}
                for label, value in recent_status_counts.items()
            ],
            "hot_paths": [
                {"label": label, "value": value}
                for label, value in recent_paths.most_common(6)
            ],
        },
        "alerts": alerts,
        "traffic": traffic,
        "top_ips": top_ips,
        "meta": {
            "target_backend": TARGET_BACKEND,
            "proxy_log_exists": PROXY_LOG_PATH.exists(),
            "analyzer_last_position": analyzer_state.get("last_position", 0),
            "analyzer_last_update": _format_timestamp(analyzer_state.get("last_update")),
            "generated_at": datetime.now().strftime("%d %b %Y, %I:%M:%S %p"),
        },
    }


@app.get("/dashboard")
async def dashboard() -> FileResponse:
    return FileResponse(FRONTEND_DIR / "index.html")


@app.get("/dashboard/api/state")
async def dashboard_state() -> JSONResponse:
    return JSONResponse(content=_build_dashboard_state())


@app.get("/health")
async def health_check() -> dict[str, str]:
    return {"status": "healthy", "target": TARGET_BACKEND}


@app.api_route(
    "/{path:path}",
    methods=["GET", "POST", "PUT", "DELETE", "PATCH", "OPTIONS", "HEAD"],
)
async def proxy(request: Request, path: str):
    start_time = datetime.now()
    body = await request.body()

    target_url = f"{TARGET_BACKEND}/{path}"
    if request.query_params:
        target_url += f"?{request.query_params}"

    headers = dict(request.headers)
    headers.pop("host", None)

    client_ip = request.client.host if request.client else "unknown"
    if "x-forwarded-for" in headers:
        headers["x-forwarded-for"] += f", {client_ip}"
    else:
        headers["x-forwarded-for"] = client_ip

    headers["x-forwarded-proto"] = request.url.scheme
    logger.info("Proxying %s %s from %s", request.method, target_url, client_ip)

    try:
        resp = await client.request(
            method=request.method,
            url=target_url,
            headers=headers,
            content=body,
            follow_redirects=True,
        )

        log_entry = {
            "timestamp": start_time.isoformat(),
            "method": request.method,
            "path": path,
            "query": str(request.query_params),
            "client_ip": client_ip,
            "user_agent": request.headers.get("user-agent"),
            "response_status": resp.status_code,
            "response_time_ms": (datetime.now() - start_time).total_seconds() * 1000,
            "request_body_preview": body.decode("utf-8", errors="ignore")[:200],
            "response_size": len(resp.content),
        }

        with PROXY_LOG_PATH.open("a", encoding="utf-8") as file:
            file.write(json.dumps(log_entry) + "\n")

        return Response(
            content=resp.content,
            status_code=resp.status_code,
            headers=dict(resp.headers),
        )
    except httpx.ConnectError as exc:
        logger.error("Connection error to backend: %s", exc)
        return JSONResponse(
            status_code=502,
            content={"error": "Bad Gateway", "detail": "Cannot connect to backend server"},
        )
    except Exception as exc:
        logger.error("Unexpected error: %s", exc, exc_info=True)
        return JSONResponse(
            status_code=500,
            content={"error": "Internal Server Error", "detail": str(exc)},
        )


@app.on_event("shutdown")
async def shutdown():
    await client.aclose()
