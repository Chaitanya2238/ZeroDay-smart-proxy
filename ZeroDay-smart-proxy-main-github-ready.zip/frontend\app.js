const summaryMetrics = document.getElementById("summaryMetrics");
const servicesList = document.getElementById("servicesList");
const topIps = document.getElementById("topIps");
const requestStatuses = document.getElementById("requestStatuses");
const threatTypes = document.getElementById("threatTypes");
const statusCodes = document.getElementById("statusCodes");
const hotPaths = document.getElementById("hotPaths");
const alertsList = document.getElementById("alertsList");
const trafficTable = document.getElementById("trafficTable");
const refreshButton = document.getElementById("refreshButton");

function formatNumber(value) {
  return new Intl.NumberFormat().format(value || 0);
}

function setText(id, value) {
  const node = document.getElementById(id);
  if (node) {
    node.textContent = value;
  }
}

function renderEmpty(target, message) {
  target.innerHTML = `<div class="empty-state">${message}</div>`;
}

function renderSummary(summary) {
  const cards = [
    ["Requests Processed", formatNumber(summary.total_requests_processed), "Requests seen by the analyzer pipeline."],
    ["Flagged by Tier 1", formatNumber(summary.requests_flagged), "Requests matching fast signatures or heuristics."],
    ["Threat Alerts", formatNumber(summary.threats_detected), "Alerts loaded from the available stores."],
    ["High Severity", formatNumber(summary.high_severity_alerts), "Alerts with severity 7 or above."],
    ["AI Analyses", formatNumber(summary.ai_analyses), "Requests escalated to the semantic analysis tier."]
  ];

  summaryMetrics.innerHTML = cards.map(([label, value, subtext]) => `
    <article class="metric-card">
      <p class="metric-label">${label}</p>
      <h4 class="metric-value">${value}</h4>
      <p class="metric-subtext">${subtext}</p>
    </article>
  `).join("");

  setText("latestAlertTime", summary.latest_alert_time || "No alerts yet");
  setText(
    "heroInsight",
    summary.latest_alert_time
      ? `Most recent alert recorded at ${summary.latest_alert_time}.`
      : "Proxy traffic and analyzer output will appear here once the system starts logging."
  );
}

function renderServices(services) {
  servicesList.innerHTML = services.map((service) => `
    <article class="status-item">
      <div class="status-row">
        <strong><span class="status-dot status-${service.status}"></span>${service.name}</strong>
        <span class="pill severity-low">${service.status}</span>
      </div>
      <p class="status-detail">${service.detail}</p>
    </article>
  `).join("");
}

function renderIps(items) {
  if (!items.length) {
    renderEmpty(topIps, "No suspicious IP activity has been recorded yet.");
    return;
  }

  topIps.innerHTML = items.map((item) => `
    <article class="ip-card">
      <div class="ip-row">
        <strong><code>${item.ip}</code></strong>
        <span>${formatNumber(item.count)} flagged events</span>
      </div>
      <p>${item.threats.length ? item.threats.map(([name, count]) => `${name} (${count})`).join(", ") : "Threat taxonomy not available yet."}</p>
    </article>
  `).join("");
}

function renderBars(target, items, emptyMessage) {
  if (!items.length || items.every((item) => !item.value)) {
    renderEmpty(target, emptyMessage);
    return;
  }

  const maxValue = Math.max(...items.map((item) => item.value), 1);
  target.innerHTML = items.map((item) => `
    <div class="chart-row">
      <div class="chart-row-top">
        <span>${item.label}</span>
        <strong>${formatNumber(item.value)}</strong>
      </div>
      <div class="chart-track">
        <div class="chart-bar" style="width:${(item.value / maxValue) * 100}%"></div>
      </div>
    </div>
  `).join("");
}

function renderAlerts(alerts) {
  if (!alerts.length) {
    renderEmpty(alertsList, "No alerts are available yet. Run traffic through the proxy and analyzer to populate this feed.");
    return;
  }

  alertsList.innerHTML = alerts.map((alert) => `
    <article class="alert-card">
      <div class="alert-header">
        <div>
          <p class="mini-label">Alert #${alert.alert_id || "-"}</p>
          <h4>${alert.threat_type}</h4>
        </div>
        <span class="pill severity-${alert.severity_label}">${alert.severity_label} ${alert.severity}</span>
      </div>
      <div class="alert-meta">
        <span><code>${alert.method}</code> <code>${alert.path}</code></span>
        <span>${alert.timestamp || "Unknown time"}</span>
      </div>
      <p>Client <code>${alert.client_ip}</code> returned status <code>${alert.status_code}</code>. Confidence: ${alert.confidence}%.</p>
      <p>Recommended action: <strong>${alert.recommended_action}</strong></p>
      ${alert.body_preview ? `<p><code>${alert.body_preview}</code></p>` : ""}
      ${alert.triggered_rules?.length ? `
        <div class="rule-list">
          ${alert.triggered_rules.slice(0, 4).map((rule) => `<span class="rule-chip">${rule}</span>`).join("")}
        </div>
      ` : ""}
    </article>
  `).join("");
}

function renderTraffic(items) {
  if (!items.length) {
    renderEmpty(trafficTable, "No proxy.log entries are available yet. Once the proxy handles traffic, this table will populate automatically.");
    return;
  }

  const header = `
    <div class="table-row header">
      <div class="table-cell"><strong>Timestamp</strong></div>
      <div class="table-cell"><strong>Method</strong></div>
      <div class="table-cell"><strong>Path</strong></div>
      <div class="table-cell"><strong>Status</strong></div>
      <div class="table-cell"><strong>Latency</strong></div>
      <div class="table-cell"><strong>Client</strong></div>
    </div>
  `;

  const rows = items.map((entry) => `
    <div class="table-row">
      <div class="table-cell">
        <strong>${entry.timestamp || "-"}</strong>
        <span class="muted">${entry.query || "No query string"}</span>
      </div>
      <div class="table-cell"><code>${entry.method}</code></div>
      <div class="table-cell">
        <strong><code>${entry.path}</code></strong>
        <span class="muted">${entry.user_agent || "Unknown agent"}</span>
      </div>
      <div class="table-cell"><code>${entry.status_code}</code></div>
      <div class="table-cell">${entry.response_time_ms} ms</div>
      <div class="table-cell">
        <strong><code>${entry.client_ip}</code></strong>
        <span class="muted">${formatNumber(entry.response_size)} bytes</span>
      </div>
    </div>
  `).join("");

  trafficTable.innerHTML = header + rows;
}

async function loadDashboardState() {
  refreshButton.disabled = true;
  refreshButton.textContent = "Refreshing...";

  try {
    const response = await fetch("/dashboard/api/state", { cache: "no-store" });
    if (!response.ok) {
      throw new Error(`Dashboard API returned ${response.status}`);
    }

    const data = await response.json();
    setText("targetBackend", `Target backend: ${data.meta.target_backend}`);
    setText("generatedAt", `Updated ${data.meta.generated_at}`);

    renderSummary(data.summary);
    renderServices(data.services);
    renderIps(data.top_ips);
    renderBars(requestStatuses, data.charts.request_statuses, "Request status data is not available yet.");
    renderBars(threatTypes, data.charts.threat_types, "Threat type data will appear after detections are recorded.");
    renderBars(statusCodes, data.charts.recent_status_codes, "Recent status codes will appear when proxy traffic is logged.");
    renderBars(hotPaths, data.charts.hot_paths, "Hot route data will appear after requests flow through the proxy.");
    renderAlerts(data.alerts);
    renderTraffic(data.traffic);
  } catch (error) {
    console.error(error);
    renderEmpty(summaryMetrics, "Unable to load dashboard state. Check whether the FastAPI app is running.");
  } finally {
    refreshButton.disabled = false;
    refreshButton.textContent = "Refresh Data";
  }
}

refreshButton.addEventListener("click", loadDashboardState);
loadDashboardState();
setInterval(loadDashboardState, 15000);
